# Online Python Playground
# Use the online IDE to write, edit & run your Python code
# Create, edit & delete files online

import pandas as pd 
import numpy as np 


base_array = np.array(['A', 'C', 'G', 'U'])
encoded_bases_array = pd.get_dummies(base_array).astype('float32').values 
print('encoded bases array:', encoded_bases_array)